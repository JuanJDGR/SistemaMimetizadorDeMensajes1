Para m�s informaci�n de c�mo instalar librer�as, mire: http://www.arduino.cc/en/Guide/Libraries
